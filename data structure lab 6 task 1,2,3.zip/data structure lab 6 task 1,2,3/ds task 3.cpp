#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int val) {
        data = val;
        next = nullptr;
    }
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList() {
        head = nullptr;
    }

    int countNodes() {
        int count = 0;
        Node* temp = head;
        while (temp != nullptr) {
            count++;
            temp = temp->next;
        }
        return count;
    }

    void insertAtPosition(int value, int pos) {
        Node* newNode = new Node(value);

        if (pos <= 0) {
            cout << "Invalid position!\n";
            return;
        }

        if (pos == 1) {
            newNode->next = head;
            head = newNode;
            return;
        }

        Node* temp = head;
        for (int i = 1; i < pos - 1 && temp != nullptr; i++) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Position out of range!\n";
            return;
        }

        newNode->next = temp->next;
        temp->next = newNode;
    }

    void deleteAtPosition(int pos) {
        if (head == nullptr || pos <= 0) {
            cout << "Invalid operation!\n";
            return;
        }

        Node* temp = head;

        if (pos == 1) {
            head = head->next;
            delete temp;
            return;
        }

        Node* prev = nullptr;
        for (int i = 1; i < pos && temp != nullptr; i++) {
            prev = temp;
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Position out of range!\n";
            return;
        }

        prev->next = temp->next;
        delete temp;
    }

    void search(int value) {
        Node* temp = head;
        int pos = 1;

        while (temp != nullptr) {
            if (temp->data == value) {
                cout << "Element found at position: " << pos << endl;
                return;
            }
            temp = temp->next;
            pos++;
        }

        cout << "Element not found!\n";
    }

    void display() {
        Node* temp = head;
        if (temp == nullptr) {
            cout << "List is empty!\n";
            return;
        }

        cout << "List: ";
        while (temp != nullptr) {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "NULL\n";
    }
};

int main() {
    LinkedList list;
    int choice, value, pos;

    do {
        cout << "\n===== MENU =====\n";
        cout << "1. Insert at position\n";
        cout << "2. Delete at position\n";
        cout << "3. Search element\n";
        cout << "4. Count nodes\n";
        cout << "5. Display list\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            cout << "Enter position: ";
            cin >> pos;
            list.insertAtPosition(value, pos);
            break;

        case 2:
            cout << "Enter position to delete: ";
            cin >> pos;
            list.deleteAtPosition(pos);
            break;

        case 3:
            cout << "Enter value to search: ";
            cin >> value;
            list.search(value);
            break;

        case 4:
            cout << "Total nodes: " << list.countNodes() << endl;
            break;

        case 5:
            list.display();
            break;

        case 0:
            cout << "Exiting...\n";
            break;

        default:
            cout << "Invalid choice!\n";
        }

    } while (choice != 0);

    return 0;
}