#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
    Node* prev;

    Node(int value) {
        data = value;
        next = nullptr;
        prev = nullptr;
    }
};

class DoublyLinkedList {
private:
    Node* head;

public:
    DoublyLinkedList() {
        head = nullptr;
    }

    void insertAtEnd(int value) {
        Node* newNode = new Node(value);

        if (head == nullptr) {
            head = newNode;
            return;
        }

        Node* temp = head;

        while (temp->next != nullptr) {
            temp = temp->next;
        }

        temp->next = newNode;
        newNode->prev = temp;
    }

    void insertAtStart(int value) {
        Node* newNode = new Node(value);

        if (head == nullptr) {
            head = newNode;
            return;
        }

        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }

    void insertAtPosition(int value, int position) {
        if (position <= 1 || head == nullptr) {
            insertAtStart(value);
            return;
        }

        Node* newNode = new Node(value);
        Node* temp = head;
        int count = 1;

        while (temp->next != nullptr && count < position - 1) {
            temp = temp->next;
            count++;
        }

        if (temp->next == nullptr) {
            temp->next = newNode;
            newNode->prev = temp;
        }
        else {
            newNode->next = temp->next;
            newNode->prev = temp;

            temp->next->prev = newNode;
            temp->next = newNode;
        }
    }

    void deleteByValue(int value) {

        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Node* temp = head;

        if (head->data == value) {
            head = head->next;

            if (head != nullptr) {
                head->prev = nullptr;
            }

            delete temp;
            cout << value << " deleted from the list.\n";
            return;
        }

        while (temp != nullptr && temp->data != value) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << value << " not found in the list.\n";
            return;
        }

        if (temp->next == nullptr) {
            temp->prev->next = nullptr;
            delete temp;
        }
        else {
           
            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;
            delete temp;
        }

        cout << value << " deleted from the list.\n";
    }

    void displayForward() {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Node* temp = head;

        cout << "Forward Traversal: ";

        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }

        cout << endl;
    }

    void displayReverse() {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Node* temp = head;

        while (temp->next != nullptr) {
            temp = temp->next;
        }

        cout << "Reverse Traversal: ";

        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->prev;
        }

        cout << endl;
    }
};

int main() {
    DoublyLinkedList dll;

    dll.insertAtEnd(10);
    dll.insertAtEnd(20);
    dll.insertAtEnd(30);

    cout << "List after inserting at end:\n";
    dll.displayForward();

    dll.insertAtStart(5);

    cout << "\nList after inserting at start:\n";
    dll.displayForward();

    dll.insertAtPosition(15, 3);

    cout << "\nList after inserting 15 at position 3:\n";
    dll.displayForward();

    cout << "\nDisplaying list in reverse:\n";
    dll.displayReverse();

    dll.deleteByValue(5);

    cout << "\nList after deleting 5:\n";
    dll.displayForward();

    dll.deleteByValue(30);

    cout << "\nList after deleting 30:\n";
    dll.displayForward();

    cout << "\nFinal Reverse Traversal:\n";
    dll.displayReverse();

    return 0;
}