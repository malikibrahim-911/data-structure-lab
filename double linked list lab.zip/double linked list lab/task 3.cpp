#include <iostream>
using namespace std;

class PlayerNode {
public:
    int playerID;
    int score;

    PlayerNode* next;

    PlayerNode(int id, int s) {
        playerID = id;
        score = s;
        next = nullptr;
    }
};

class GameSystem {
private:
    PlayerNode* tail;      
    PlayerNode* current;   

public:
    GameSystem() {
        tail = nullptr;
        current = nullptr;
    }

    void addPlayer(int id, int score) {
        PlayerNode* newPlayer = new PlayerNode(id, score);

        if (tail == nullptr) {
            tail = newPlayer;
            tail->next = tail; 
            current = tail;
        }
        else {
            newPlayer->next = tail->next;
            tail->next = newPlayer;
            tail = newPlayer;
        }

        cout << "Player " << id << " joined the game.\n";
    }

    void displayPlayers() {
        if (tail == nullptr) {
            cout << "\nNo players in the game.\n";
            return;
        }

        PlayerNode* temp = tail->next;

        cout << "\n===== PLAYERS IN GAME =====\n";

        do {
            cout << "Player ID: " << temp->playerID
                << " | Score: " << temp->score << endl;

            temp = temp->next;
        } while (temp != tail->next);

        cout << "===========================\n";
    }

    void nextTurn() {
        if (current == nullptr) {
            cout << "\nNo players available.\n";
            return;
        }

        current = current->next;

        cout << "\nNow it's Player "
            << current->playerID
            << "'s turn.\n";
    }

    void skipPlayer() {
        if (current == nullptr) {
            cout << "\nNo players available.\n";
            return;
        }

        cout << "\nPlayer "
            << current->next->playerID
            << " is skipped!\n";

        current = current->next->next;

        cout << "Now it's Player "
            << current->playerID
            << "'s turn.\n";
    }

    void removePlayer(int id) {
        if (tail == nullptr) {
            cout << "\nNo players in the game.\n";
            return;
        }

        PlayerNode* curr = tail->next;
        PlayerNode* prev = tail;

        do {
            if (curr->playerID == id) {

                if (curr == tail && curr->next == tail) {
                    cout << "\nPlayer " << id << " removed.\n";
                    delete curr;
                    tail = nullptr;
                    current = nullptr;
                    return;
                }

                if (curr == tail) {
                    tail = prev;
                }

                prev->next = curr->next;

                if (current == curr) {
                    current = curr->next;
                }

                cout << "\nPlayer " << id << " removed from the game.\n";

                delete curr;
                return;
            }

            prev = curr;
            curr = curr->next;

        } while (curr != tail->next);

        cout << "\nPlayer not found.\n";
    }

    bool isGameOver() {
        if (tail != nullptr && tail->next == tail) {
            cout << "\n===== GAME OVER =====\n";
            cout << "Winner is Player "
                << tail->playerID
                << " with Score "
                << tail->score << "!\n";
            cout << "=====================\n";

            return true;
        }

        return false;
    }

    void showCurrentPlayer() {
        if (current == nullptr) {
            cout << "\nNo current player.\n";
            return;
        }

        cout << "\nCurrent Turn: Player "
            << current->playerID
            << endl;
    }
};

int main() {
    GameSystem game;

    game.addPlayer(1, 50);
    game.addPlayer(2, 40);
    game.addPlayer(3, 60);
    game.addPlayer(4, 30);

    game.displayPlayers();

    game.showCurrentPlayer();

    game.nextTurn();
    game.nextTurn();

    game.skipPlayer();

    game.removePlayer(2);
    game.displayPlayers();

    game.removePlayer(4);
    game.displayPlayers();

    game.removePlayer(1);
    game.displayPlayers();

    game.isGameOver();

    return 0;
}