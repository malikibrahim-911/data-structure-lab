#include <iostream>
#include <string>
using namespace std;

class SongNode {
public:
    int songID;
    string songName;
    float duration;

    SongNode* next;
    SongNode* prev;

    SongNode(int id, string name, float dur) {
        songID = id;
        songName = name;
        duration = dur;
        next = nullptr;
        prev = nullptr;
    }
};

class PlaylistManager {
private:
    SongNode* head;
    SongNode* tail;
    SongNode* current; 

public:

    PlaylistManager() {
        head = nullptr;
        tail = nullptr;
        current = nullptr;
    }

    void addSong(int id, string name, float duration) {
        SongNode* newSong = new SongNode(id, name, duration);

        if (head == nullptr) {
            head = tail = current = newSong;
        }
        else {
            tail->next = newSong;
            newSong->prev = tail;
            tail = newSong;
        }

        cout << "Song Added: " << name << endl;
    }

    void displayPlaylist() {
        if (head == nullptr) {
            cout << "\nPlaylist is empty.\n";
            return;
        }

        SongNode* temp = head;

        cout << "\n===== PLAYLIST =====\n";

        while (temp != nullptr) {
            cout << "ID: " << temp->songID
                << " | Name: " << temp->songName
                << " | Duration: " << temp->duration << " mins\n";

            temp = temp->next;
        }

        cout << "====================\n";
    }

    void deleteSong(string name) {
        if (head == nullptr) {
            cout << "\nPlaylist is empty.\n";
            return;
        }

        SongNode* temp = head;

        while (temp != nullptr && temp->songName != name) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "\nSong not found.\n";
            return;
        }

        if (temp == head) {
            head = head->next;

            if (head != nullptr)
                head->prev = nullptr;
        }

        // If deleting tail
        if (temp == tail) {
            tail = tail->prev;

            if (tail != nullptr)
                tail->next = nullptr;
        }

        if (temp->prev != nullptr) {
            temp->prev->next = temp->next;
        }

        if (temp->next != nullptr) {
            temp->next->prev = temp->prev;
        }

        if (current == temp) {
            current = temp->next != nullptr ? temp->next : temp->prev;
        }

        cout << "\nDeleted Song: " << temp->songName << endl;

        delete temp;
    }

    void playCurrent() {
        if (current == nullptr) {
            cout << "\nNo song available.\n";
            return;
        }

        cout << "\nNow Playing: "
            << current->songName
            << " (" << current->duration << " mins)\n";
    }

    void playNext() {
        if (current == nullptr) {
            cout << "\nPlaylist is empty.\n";
            return;
        }

        if (current->next == nullptr) {
            cout << "\nThis is the last song.\n";
            return;
        }

        current = current->next;

        cout << "\nPlaying Next Song: "
            << current->songName << endl;
    }

    void playPrevious() {
        if (current == nullptr) {
            cout << "\nPlaylist is empty.\n";
            return;
        }

        if (current->prev == nullptr) {
            cout << "\nThis is the first song.\n";
            return;
        }

        current = current->prev;

        cout << "\nPlaying Previous Song: "
            << current->songName << endl;
    }

    void reversePlaylist() {
        if (head == nullptr) {
            cout << "\nPlaylist is empty.\n";
            return;
        }

        SongNode* temp = nullptr;
        SongNode* currentNode = head;

        while (currentNode != nullptr) {
            temp = currentNode->prev;
            currentNode->prev = currentNode->next;
            currentNode->next = temp;

            currentNode = currentNode->prev;
        }

        temp = head;
        head = tail;
        tail = temp;

        cout << "\nPlaylist Reversed Successfully.\n";
    }
};

int main() {
    PlaylistManager playlist;

    playlist.addSong(101, "Shape of You", 4.2);
    playlist.addSong(102, "Blinding Lights", 3.5);
    playlist.addSong(103, "Perfect", 4.8);
    playlist.addSong(104, "Levitating", 3.9);

    playlist.displayPlaylist();

    playlist.playCurrent();

    playlist.playNext();
    playlist.playNext();

    playlist.playPrevious();

    playlist.deleteSong("Perfect");

    playlist.displayPlaylist();

    playlist.reversePlaylist();

    playlist.displayPlaylist();

    return 0;
}