#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
};

Node* insertAtBeginning(Node* head, int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = head;
    newNode->prev = NULL;

    if (head != NULL) {
        head->prev = newNode;
    }

    return newNode;
}

Node* insertAtEnd(Node* head, int value) {
   
    if (head == NULL) {
        Node* newNode = new Node();
        newNode->data = value;
        newNode->next = NULL;
        newNode->prev = NULL;
        return newNode;
    }

    if (head->next == NULL) {
        Node* newNode = new Node();
        newNode->data = value;
        newNode->next = NULL;
        newNode->prev = head;

        head->next = newNode;
        return head;
    }

    insertAtEnd(head->next, value);

    return head;
}

Node* insertAtPosition(Node* head, int value, int position) {
    
    if (position <= 0) {
        cout << "Invalid Position!" << endl;
        return head;
    }

    if (position == 1) {
        return insertAtBeginning(head, value);
    }

    if (head == NULL) {
        cout << "Position out of range!" << endl;
        return head;
    }

    if (position == 2) {
        Node* newNode = new Node();
        newNode->data = value;

        newNode->next = head->next;
        newNode->prev = head;

        if (head->next != NULL) {
            head->next->prev = newNode;
        }

        head->next = newNode;

        return head;
    }

    head->next = insertAtPosition(head->next, value, position - 1);

    return head;
}

Node* deleteByValue(Node* head, int value) {
   
    if (head == NULL) {
        cout << "Value not found!" << endl;
        return NULL;
    }

    if (head->data == value) {
        Node* temp = head->next;

        if (temp != NULL) {
            temp->prev = head->prev;
        }

        delete head;
        return temp;
    }

    head->next = deleteByValue(head->next, value);

    return head;
}

Node* deleteAtPosition(Node* head, int position) {
   
    if (head == NULL || position <= 0) {
        cout << "Invalid Position!" << endl;
        return head;
    }

    if (position == 1) {
        Node* temp = head->next;

        if (temp != NULL) {
            temp->prev = NULL;
        }

        delete head;
        return temp;
    }

    head->next = deleteAtPosition(head->next, position - 1);

    return head;
}

int search(Node* head, int value, int position = 1) {
    
    if (head == NULL) {
        return -1;
    }

    if (head->data == value) {
        return position;
    }

    return search(head->next, value, position + 1);
}

void printForward(Node* head) {
    if (head == NULL) {
        cout << "NULL" << endl;
        return;
    }

    cout << head->data << " <-> ";
    printForward(head->next);
}

void printReverse(Node* tail) {
    if (tail == NULL) {
        cout << "NULL" << endl;
        return;
    }

    cout << tail->data << " <-> ";
    printReverse(tail->prev);
}

Node* getTail(Node* head) {
    if (head == NULL || head->next == NULL) {
        return head;
    }

    return getTail(head->next);
}

bool isPalindrome(Node* left, Node* right) {
    
    if (left == NULL || right == NULL) {
        return true;
    }

    if (left == right || left->prev == right) {
        return true;
    }

    if (left->data != right->data) {
        return false;
    }

    return isPalindrome(left->next, right->prev);
}

int main() {
    Node* head = NULL;

    head = insertAtBeginning(head, 10);
    head = insertAtEnd(head, 20);
    head = insertAtEnd(head, 30);
    head = insertAtPosition(head, 20, 3);

    cout << "Forward List: ";
    printForward(head);

    Node* tail = getTail(head);

    cout << "Reverse List: ";
    printReverse(tail);

    int pos = search(head, 30);

    if (pos != -1) {
        cout << "30 found at position: " << pos << endl;
    }
    else {
        cout << "30 not found!" << endl;
    }

    head = deleteByValue(head, 10);

    cout << "After deleting 10: ";
    printForward(head);

    head = deleteAtPosition(head, 2);

    cout << "After deleting position 2: ";
    printForward(head);

    tail = getTail(head);

    if (isPalindrome(head, tail)) {
        cout << "The list is a palindrome." << endl;
    }
    else {
        cout << "The list is not a palindrome." << endl;
    }

    return 0;
}