#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void printList(Node* head) {
    if (head == NULL) {
        cout << "NULL" << endl;
        return;
    }

    cout << head->data << " -> ";
    printList(head->next);
}

Node* insertAtBeginning(Node* head, int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = head;

    return newNode;
}

Node* insertAtEnd(Node* head, int value) {
    
    if (head == NULL) {
        Node* newNode = new Node();
        newNode->data = value;
        newNode->next = NULL;
        return newNode;
    }

    head->next = insertAtEnd(head->next, value);

    return head;
}

Node* insertAtPosition(Node* head, int value, int position) {
   
    if (position <= 0) {
        cout << "Invalid Position!" << endl;
        return head;
    }

    if (position == 1) {
        Node* newNode = new Node();
        newNode->data = value;
        newNode->next = head;
        return newNode;
    }

    if (head == NULL) {
        cout << "Position out of range!" << endl;
        return head;
    }

    head->next = insertAtPosition(head->next, value, position - 1);

    return head;
}

Node* deleteByValue(Node* head, int value) {
    
    if (head == NULL) {
        cout << "Value not found!" << endl;
        return NULL;
    }

    if (head->data == value) {
        Node* temp = head->next;
        delete head;
        return temp;
    }

    head->next = deleteByValue(head->next, value);

    return head;
}

Node* deleteAtPosition(Node* head, int position) {
    
    if (head == NULL || position <= 0) {
        cout << "Invalid Position!" << endl;
        return head;
    }

    if (position == 1) {
        Node* temp = head->next;
        delete head;
        return temp;
    }

    head->next = deleteAtPosition(head->next, position - 1);

    return head;
}

int search(Node* head, int value, int position = 1) {
   
    if (head == NULL) {
        return -1;
    }

    if (head->data == value) {
        return position;
    }

    return search(head->next, value, position + 1);
}

int main() {
    Node* head = NULL;

    head = insertAtBeginning(head, 10);
    cout << "After inserting 10 at beginning: ";
    printList(head);

    head = insertAtEnd(head, 20);
    cout << "After inserting 20 at end: ";
    printList(head);

    head = insertAtEnd(head, 30);
    cout << "After inserting 30 at end: ";
    printList(head);

    head = insertAtPosition(head, 15, 2);
    cout << "After inserting 15 at position 2: ";
    printList(head);

    head = deleteByValue(head, 20);
    cout << "After deleting value 20: ";
    printList(head);

    head = deleteAtPosition(head, 2);
    cout << "After deleting node at position 2: ";
    printList(head);

    int pos = search(head, 30);

    if (pos != -1) {
        cout << "Value 30 found at position: " << pos << endl;
    }
    else {
        cout << "Value 30 not found!" << endl;
    }

    return 0;
}