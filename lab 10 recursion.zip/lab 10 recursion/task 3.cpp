#include <iostream>
using namespace std;

int findMax(int arr[], int size) {
    
    if (size == 1) {
        return arr[0];
    }

    int maxOfRest = findMax(arr, size - 1);

    if (arr[size - 1] > maxOfRest) {
        return arr[size - 1];
    }
    else {
        return maxOfRest;
    }
}

int main() {
    int arr[] = { 12, 5, 18, 7, 3 };
    int size = 5;

    int maximum = findMax(arr, size);

    cout << "Maximum element: " << maximum << endl;

    return 0;
}