#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void printList(Node* head) {
    
    if (head == NULL) {
        return;
    }

    cout << head->data << " ";

    printList(head->next);
}

int main() {
   
    Node* head = new Node();
    Node* second = new Node();
    Node* third = new Node();

    head->data = 10;
    second->data = 20;
    third->data = 30;

    head->next = second;
    second->next = third;
    third->next = NULL;

    cout << "Linked List Elements: ";
    printList(head);

    return 0;
}