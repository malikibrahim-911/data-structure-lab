#include <iostream>
using namespace std;

int findLargestIndex(int arr[], int size, int index = 1, int maxIndex = 0) {
   
    if (index == size) {
        return maxIndex;
    }

    if (arr[index] > arr[maxIndex]) {
        maxIndex = index;
    }

    return findLargestIndex(arr, size, index + 1, maxIndex);
}

bool subsetSum(int arr[], int size, int target, int index = 0) {
    
    if (target == 0) {
        return true;
    }

    if (index == size || target < 0) {
        return false;
    }

    return subsetSum(arr, size, target - arr[index], index + 1) ||
        subsetSum(arr, size, target, index + 1);
}

int findMagicNumber(int arr[], int size) {
    
    if (size <= 1) {
        return -1;
    }

    int maxIndex = findLargestIndex(arr, size);

    int largest = arr[maxIndex];

    int remaining[100];
    int j = 0;

    copyArray(0);

    if (subsetSum(remaining, size - 1, largest)) {
        return largest;
    }

    remaining[maxIndex < size - 1 ? maxIndex : size - 2] = 0;

    return findMagicNumber(remaining, size - 1);
}

int main() {
    int arr[] = { 2, 3, 5, 8, 13 };
    int size = 5;

    int result = findMagicNumber(arr, size);

    if (result != -1) {
        cout << "Magic Number: " << result << endl;
    }
    else {
        cout << "No Magic Number Found!" << endl;
    }

    return 0;
}