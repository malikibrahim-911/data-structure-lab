#include <iostream>
#include <string>
using namespace std;

class Node {
public:
    string name;
    int priority;
    Node* next;

    Node(string n, int p) {
        name = n;
        priority = p;
        next = nullptr;
    }
};

class ReservationQueue {
private:
    Node* head;

public:
    ReservationQueue() {
        head = nullptr;
    }

    void addStudent(string name, int priority) {
        Node* newNode = new Node(name, priority);

        if (head == nullptr || priority > head->priority) {
            newNode->next = head;
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr && temp->next->priority >= priority) {
                temp = temp->next;
            }
            newNode->next = temp->next;
            temp->next = newNode;
        }

        cout << name << " added with priority " << priority << endl;
    }

    void removeStudent(string name) {
        if (head == nullptr) {
            cout << "No reservations.\n";
            return;
        }

        if (head->name == name) {
            Node* temp = head;
            head = head->next;
            delete temp;
            cout << name << " removed.\n";
            return;
        }

        Node* temp = head;
        Node* prev = nullptr;

        while (temp != nullptr && temp->name != name) {
            prev = temp;
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Student not found!\n";
            return;
        }

        prev->next = temp->next;
        delete temp;
        cout << name << " removed.\n";
    }

    void updatePriority(string name, int newPriority) {
        removeStudent(name);
        addStudent(name, newPriority);
        cout << "Priority updated for " << name << endl;
    }

    void serveNext() {
        if (head == nullptr) {
            cout << "No students waiting.\n";
            return;
        }

        Node* temp = head;
        cout << "Serving: " << temp->name << endl;
        head = head->next;
        delete temp;
    }

    void display() {
        if (head == nullptr) {
            cout << "No reservations.\n";
            return;
        }

        Node* temp = head;
        while (temp != nullptr) {
            cout << temp->name << "(P:" << temp->priority << ") -> ";
            temp = temp->next;
        }
        cout << "NULL\n";
    }

    int countStudents() {
        int count = 0;
        Node* temp = head;
        while (temp != nullptr) {
            count++;
            temp = temp->next;
        }
        return count;
    }
};

class Book {
public:
    string title;
    ReservationQueue queue;

    Book(string t) {
        title = t;
    }

    void showQueue() {
        cout << "\nBook: " << title << endl;
        queue.display();
    }
};

int main() {
    
    Book book1("Data Structures");
    Book book2("Operating Systems");

    book1.queue.addStudent("Ali", 2);
    book1.queue.addStudent("Sara", 3);
    book1.queue.addStudent("Ahmed", 1);

    book2.queue.addStudent("Ayesha", 2);
    book2.queue.addStudent("Bilal", 1);

    book1.showQueue();
    book2.showQueue();

    book1.queue.updatePriority("Ahmed", 5);

    book2.queue.removeStudent("Bilal");

    book1.queue.serveNext();

    book1.showQueue();
    book2.showQueue();

    cout << "\nBook1 Total: " << book1.queue.countStudents() << endl;
    cout << "Book2 Total: " << book2.queue.countStudents() << endl;

    return 0;
}