#include <iostream>
#include <string>
using namespace std;

class Node {
public:
    string name;
    Node* next;

    Node(string n) {
        name = n;
        next = nullptr;
    }
};

class PatientQueue {
private:
    Node* head;

public:
    PatientQueue() {
        head = nullptr;
    }

    void addPatient(string name) {
        Node* newNode = new Node(name);

        if (head == nullptr) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newNode;
        }

        cout << name << " added to queue.\n";
    }

    void removePatient(string name) {
        if (head == nullptr) {
            cout << "Queue is empty!\n";
            return;
        }

        if (head->name == name) {
            Node* temp = head;
            head = head->next;
            delete temp;
            cout << name << " removed from queue.\n";
            return;
        }

        Node* temp = head;
        Node* prev = nullptr;

        while (temp != nullptr && temp->name != name) {
            prev = temp;
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Patient not found!\n";
            return;
        }

        prev->next = temp->next;
        delete temp;
        cout << name << " removed from queue.\n";
    }

    void display() {
        if (head == nullptr) {
            cout << "No patients in queue.\n";
            return;
        }

        Node* temp = head;
        cout << "Patient Queue:\n";

        while (temp != nullptr) {
            cout << temp->name << " -> ";
            temp = temp->next;
        }
        cout << "NULL\n";
    }

    int countPatients() {
        int count = 0;
        Node* temp = head;

        while (temp != nullptr) {
            count++;
            temp = temp->next;
        }

        return count;
    }
};

int main() {
    PatientQueue queue;

    queue.addPatient("Ali");
    queue.addPatient("Sara");
    queue.addPatient("Ahmed");
    queue.addPatient("Ayesha");

    queue.display();

    cout << "Total Patients: " << queue.countPatients() << endl;

    queue.removePatient("Sara");

    queue.display();

    cout << "Total Patients: " << queue.countPatients() << endl;

    return 0;
}