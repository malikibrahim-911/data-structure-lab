#include <iostream>
using namespace std;

class BSTNode
{
public:
    int isbn;
    string title;
    BSTNode* left;
    BSTNode* right;

    BSTNode(int i, string t)
    {
        isbn = i;
        title = t;
        left = NULL;
        right = NULL;
    }
};

class ListNode
{
public:
    int isbn;
    string title;
    ListNode* next;

    ListNode(int i, string t)
    {
        isbn = i;
        title = t;
        next = NULL;
    }
};

BSTNode* insertBST(BSTNode* root, int isbn, string title)
{
    if (root == NULL)
    {
        return new BSTNode(isbn, title);
    }

    if (isbn < root->isbn)
    {
        root->left = insertBST(root->left, isbn, title);
    }
    else if (isbn > root->isbn)
    {
        root->right = insertBST(root->right, isbn, title);
    }

    return root;
}

void BSTtoLinkedList(BSTNode* root, ListNode*& head, ListNode*& tail)
{
    if (root == NULL)
    {
        return;
    }

    BSTtoLinkedList(root->left, head, tail);

    ListNode* newNode = new ListNode(root->isbn, root->title);

    if (head == NULL)
    {
        head = newNode;
        tail = newNode;
    }
    else
    {
        tail->next = newNode;
        tail = newNode;
    }

    BSTtoLinkedList(root->right, head, tail);
}

void printList(ListNode* head)
{
    while (head != NULL)
    {
        cout << "ISBN: " << head->isbn
             << " | Title: " << head->title << endl;

        head = head->next;
    }
}

int main()
{
    BSTNode* root = NULL;

    int n;
    int isbn;
    string title;

    cout << "Enter number of books: ";
    cin >> n;

    for (int i = 0; i < n; i++)
    {
        cout << "\nEnter ISBN: ";
        cin >> isbn;

        cin.ignore();

        cout << "Enter Title: ";
        getline(cin, title);

        root = insertBST(root, isbn, title);
    }

    ListNode* head = NULL;
    ListNode* tail = NULL;

    BSTtoLinkedList(root, head, tail);

    cout << "\nSorted Library Catalog:\n";
    printList(head);

    return 0;
}