#include <iostream>
using namespace std;

template <typename T>
class AbstractStack {
public:
    virtual void push(T) = 0;
    virtual T pop() = 0;
    virtual T top() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;
};

template <typename T>
class myStack : public AbstractStack<T> {
    T *arr, *minArr;
    int topIndex, minTop, size;

public:
    myStack(int s) {
        size = s;
        arr = new T[size];
        minArr = new T[size];
        topIndex = -1;
        minTop = -1;
    }

    void push(T val) {
        if (topIndex == size - 1) {
            cout << "Full\n"; return;
        }
        arr[++topIndex] = val;

        if (minTop == -1 || val <= minArr[minTop])
            minArr[++minTop] = val;
    }

    T pop() {
        if (topIndex == -1) {
            cout << "Empty\n"; return -1;
        }
        T val = arr[topIndex--];

        if (val == minArr[minTop])
            minTop--;

        return val;
    }

    T top() const {
        if (topIndex == -1) return -1;
        return arr[topIndex];
    }

    bool isEmpty() const { return topIndex == -1; }
    bool isFull() const { return topIndex == size - 1; }

    T getMin() const {
        if (minTop == -1) return -1;
        return minArr[minTop];
    }

    void display() const {
        for (int i = topIndex; i >= 0; i--)
            cout << arr[i] << endl;
    }
};

int main() {
    myStack<int> s(5);
    int ch, val;

    do {
        cout << "\n1.Push 2.Pop 3.Top 4.Display 5.Min 6.Exit\n";
        cin >> ch;

        if (ch == 1) {
            cin >> val;
            s.push(val);
        }
        else if (ch == 2) cout << s.pop() << endl;
        else if (ch == 3) cout << s.top() << endl;
        else if (ch == 4) s.display();
        else if (ch == 5) cout << s.getMin() << endl;

    } while (ch != 6);

    return 0;
}