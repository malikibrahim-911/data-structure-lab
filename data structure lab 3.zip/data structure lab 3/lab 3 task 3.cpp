#include <iostream>
using namespace std;

#define MAX 8

string stackArr[MAX];
int top = -1;

void parkCar(string car) {
    if (top == MAX - 1) {
        cout << "Parking Full!\n";
        return;
    }
    stackArr[++top] = car;
    cout << "Car parked.\n";
}

void display() {
    if (top == -1) {
        cout << "No cars parked.\n";
        return;
    }

    cout << "Cars in parking:\n";
    for (int i = top; i >= 0; i--) {
        cout << stackArr[i] << endl;
    }
}

void totalCars() {
    cout << "Total cars: " << top + 1 << endl;
}

void searchCar(string car) {
    for (int i = 0; i <= top; i++) {
        if (stackArr[i] == car) {
            cout << "Car found.\n";
            return;
        }
    }
    cout << "Car not found.\n";
}

void removeCar(string car) {
    if (top == -1) {
        cout << "Parking empty.\n";
        return;
    }

    string temp[MAX];
    int tempTop = -1;
    bool found = false;

    while (top != -1) {
        if (stackArr[top] == car) {
            found = true;
            top--;
            cout << "Car removed.\n";
            break;
        } else {
            temp[++tempTop] = stackArr[top--];
        }
    }

    if (!found) {
        cout << "Car not found.\n";
    }

    while (tempTop != -1) {
        stackArr[++top] = temp[tempTop--];
    }
}

int main() {
    int choice;
    string car;

    do {
        cout << "\n1. Park Car\n2. Remove Car\n3. Display\n4. Total Cars\n5. Search Car\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter car number: ";
            cin >> car;
            parkCar(car);
            break;

        case 2:
            cout << "Enter car number to remove: ";
            cin >> car;
            removeCar(car);
            break;

        case 3:
            display();
            break;

        case 4:
            totalCars();
            break;

        case 5:
            cout << "Enter car number to search: ";
            cin >> car;
            searchCar(car);
            break;
        }

    } while (choice != 0);

    return 0;
}