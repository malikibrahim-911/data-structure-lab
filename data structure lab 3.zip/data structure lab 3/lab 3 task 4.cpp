#include <iostream>
using namespace std;

string text = "";
string undoStack[100], redoStack[100];
int uTop = -1, rTop = -1;

void typeChar(char ch) {
    undoStack[++uTop] = text; 
    text += ch;
    rTop = -1; 
}

void deleteChar() {
    if (text == "") {
        cout << "Nothing to delete\n";
        return;
    }
    undoStack[++uTop] = text;
    text.pop_back();
    rTop = -1;
}

void undo() {
    if (uTop == -1) {
        cout << "Nothing to undo\n";
        return;
    }
    redoStack[++rTop] = text;
    text = undoStack[uTop--];
}

void redo() {
    if (rTop == -1) {
        cout << "Nothing to redo\n";
        return;
    }
    undoStack[++uTop] = text;
    text = redoStack[rTop--];
}

void show() {
    cout << "Text: " << text << endl;
}

int main() {
    int choice;
    char ch;

    do {
        cout << "\n1.Type 2.Delete 3.Undo 4.Redo 5.Show 0.Exit\n";
        cin >> choice;

        if (choice == 1) {
            cout << "Enter char: ";
            cin >> ch;
            typeChar(ch);
        }
        else if (choice == 2) deleteChar();
        else if (choice == 3) undo();
        else if (choice == 4) redo();
        else if (choice == 5) show();

    } while (choice != 0);

    return 0;
}