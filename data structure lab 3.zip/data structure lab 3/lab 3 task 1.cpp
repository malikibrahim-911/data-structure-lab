#include <iostream>
using namespace std;

template <typename T>
class AbstractStack {
public:
    virtual void push(T value) = 0;
    virtual T pop() = 0;
    virtual T top() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;
};

template <typename T>
class myStack : public AbstractStack<T> {
    T *arr;
    int topIndex, size;

public:
    myStack(int s) {
        size = s;
        arr = new T[size];
        topIndex = -1;
    }

    void push(T value) {
        if (topIndex == size - 1) {
            cout << "Stack Full\n";
            return;
        }
        arr[++topIndex] = value;
    }

    T pop() {
        if (topIndex == -1) {
            cout << "Stack Empty\n";
            return -1;
        }
        return arr[topIndex--];
    }

    T top() const {
        if (topIndex == -1) {
            cout << "Stack Empty\n";
            return -1;
        }
        return arr[topIndex];
    }

    bool isEmpty() const {
        return topIndex == -1;
    }

    bool isFull() const {
        return topIndex == size - 1;
    }

    void display() const {
        for (int i = topIndex; i >= 0; i--) {
            cout << arr[i] << endl;
        }
    }
};

int main() {
    myStack<int> s(5); 
    int choice, val;

    do {
        cout << "\n1.Push 2.Pop 3.Top 4.Display 5.Exit\n";
        cin >> choice;

        if (choice == 1) {
            cout << "Enter value: ";
            cin >> val;
            s.push(val);
        }
        else if (choice == 2) {
            cout << "Popped: " << s.pop() << endl;
        }
        else if (choice == 3) {
            cout << "Top: " << s.top() << endl;
        }
        else if (choice == 4) {
            s.display();
        }

    } while (choice != 5);

    return 0;
}