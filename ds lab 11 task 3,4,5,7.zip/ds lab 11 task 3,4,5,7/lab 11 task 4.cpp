#include <iostream>
using namespace std;

/*
   This program creates a BST.

   How it works:
   1. User enters values.
   2. Values are inserted in BST.
   3. Smaller values go left.
   4. Greater values go right.
   5. Recursive function finds minimum value.
   6. Recursive function finds maximum value.
*/

// Node class
class Node
{
public:
    int data;
    Node* left;
    Node* right;

    // Constructor
    Node(int value)
    {
        data = value;
        left = NULL;
        right = NULL;
    }
};

// Insert function
Node* insert(Node* root, int value)
{
    // Create node if empty
    if (root == NULL)
    {
        return new Node(value);
    }

    // Go left
    if (value < root->data)
    {
        root->left = insert(root->left, value);
    }

    // Go right
    else
    {
        root->right = insert(root->right, value);
    }

    return root;
}

// Find minimum value
Node* findMin(Node* root)
{
    // Leftmost node is minimum
    if (root->left == NULL)
    {
        return root;
    }

    return findMin(root->left);
}

// Find maximum value
Node* findMax(Node* root)
{
    // Rightmost node is maximum
    if (root->right == NULL)
    {
        return root;
    }

    return findMax(root->right);
}

int main()
{
    Node* root = NULL;

    int n, value;

    cout << "Enter number of values: ";
    cin >> n;

    cout << "Enter values: ";

    // Insert values
    for (int i = 0; i < n; i++)
    {
        cin >> value;
        root = insert(root, value);
    }

    // Print minimum value
    cout << "\nMinimum value: " << findMin(root)->data;

    // Print maximum value
    cout << "\nMaximum value: " << findMax(root)->data;

    return 0;
}