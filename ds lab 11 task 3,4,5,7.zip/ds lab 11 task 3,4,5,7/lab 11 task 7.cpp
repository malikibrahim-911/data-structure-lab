#include <iostream>
using namespace std;

/*
   This program finds the magic number.

   Magic number:
   Largest number that can be made
   from the sum of remaining numbers.

   How program works:
   1. Find largest number recursively.
   2. Remove that number from array.
   3. Check recursively if subset sum exists.
   4. If yes, return that number.
   5. Otherwise repeat with next largest number.
*/

// Function to find largest number recursively
int largest(int arr[], int n, int i, int max)
{
    // Stop when array ends
    if (i == n)
    {
        return max;
    }

    // Update maximum value
    if (arr[i] > max)
    {
        max = arr[i];
    }

    // Move to next index
    return largest(arr, n, i + 1, max);
}

// Recursive function for subset sum
bool subsetSum(int arr[], int n, int target, int i)
{
    // Target found
    if (target == 0)
    {
        return true;
    }

    // Stop if array ends or target becomes negative
    if (i == n || target < 0)
    {
        return false;
    }

    // Two choices:
    // 1. Include current element
    // 2. Skip current element
    return subsetSum(arr, n, target - arr[i], i + 1) ||
           subsetSum(arr, n, target, i + 1);
}

// Function to find magic number
int magicNumber(int arr[], int n)
{
    // No elements left
    if (n == 0)
    {
        return -1;
    }

    // Find largest value
    int max = largest(arr, n, 0, arr[0]);

    int temp[100];
    int j = 0;

    bool removed = false;

    // Copy array without largest value
    for (int i = 0; i < n; i++)
    {
        // Remove largest value only once
        if (arr[i] == max && removed == false)
        {
            removed = true;
        }
        else
        {
            temp[j] = arr[i];
            j++;
        }
    }

    // Check if largest value can be made
    // from subset of remaining numbers
    if (subsetSum(temp, j, max, 0))
    {
        return max;
    }

    // Repeat process again
    return magicNumber(temp, j);
}

int main()
{
    int n;

    // Input array size
    cout << "Enter size: ";
    cin >> n;

    int arr[100];

    // Input array elements
    cout << "Enter elements: ";

    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    // Find magic number
    int result = magicNumber(arr, n);

    // Print result
    if (result != -1)
    {
        cout << "Magic number is: " << result;
    }
    else
    {
        cout << "No magic number found.";
    }

    return 0;
}