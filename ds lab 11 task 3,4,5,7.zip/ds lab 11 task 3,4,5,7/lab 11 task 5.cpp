#include <iostream>
using namespace std;

/*
   This program creates a BST.

   How it works:
   1. User enters values.
   2. Values are inserted in BST.
   3. User enters a value to delete.
   4. Recursive delete function removes the node.
   5. In-order traversal prints updated BST.
*/

// Node class
class Node
{
public:
    int data;
    Node* left;
    Node* right;

    // Constructor
    Node(int value)
    {
        data = value;
        left = NULL;
        right = NULL;
    }
};

// Insert function
Node* insert(Node* root, int value)
{
    // Create node if empty
    if (root == NULL)
    {
        return new Node(value);
    }

    // Go left
    if (value < root->data)
    {
        root->left = insert(root->left, value);
    }

    // Go right
    else
    {
        root->right = insert(root->right, value);
    }

    return root;
}

// Find minimum node
Node* findMin(Node* root)
{
    // Leftmost node is minimum
    if (root->left == NULL)
    {
        return root;
    }

    return findMin(root->left);
}

// Delete function
Node* deleteNode(Node* root, int value)
{
    // Stop if tree is empty
    if (root == NULL)
    {
        return NULL;
    }

    // Search on left side
    if (value < root->data)
    {
        root->left = deleteNode(root->left, value);
    }

    // Search on right side
    else if (value > root->data)
    {
        root->right = deleteNode(root->right, value);
    }

    // Node found
    else
    {
        // Node with no child
        if (root->left == NULL && root->right == NULL)
        {
            delete root;
            return NULL;
        }

        // Node with one child
        else if (root->left == NULL)
        {
            Node* temp = root->right;
            delete root;
            return temp;
        }

        else if (root->right == NULL)
        {
            Node* temp = root->left;
            delete root;
            return temp;
        }

        // Node with two children
        else
        {
            Node* temp = findMin(root->right);

            root->data = temp->data;

            root->right = deleteNode(root->right, temp->data);
        }
    }

    return root;
}

// In-order traversal
void inorder(Node* root)
{
    if (root == NULL)
    {
        return;
    }

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

int main()
{
    Node* root = NULL;

    int n, value, delValue;

    cout << "Enter number of values: ";
    cin >> n;

    cout << "Enter values: ";

    // Insert values
    for (int i = 0; i < n; i++)
    {
        cin >> value;
        root = insert(root, value);
    }

    // Print original BST
    cout << "\nBST before deletion: ";
    inorder(root);

    // Input value to delete
    cout << "\nEnter value to delete: ";
    cin >> delValue;

    // Delete node
    root = deleteNode(root, delValue);

    // Print updated BST
    cout << "\nBST after deletion: ";
    inorder(root);

    return 0;
}