#include <iostream>
using namespace std;

/*
   This program creates a BST.

   How it works:
   1. User enters values.
   2. Values are inserted in BST.
   3. Smaller values go left.
   4. Greater values go right.
   5. In-order traversal prints values in sorted order.
   6. Recursive search checks if value exists or not.
*/

// Node class
class Node
{
public:
    int data;
    Node* left;
    Node* right;

    // Constructor
    Node(int value)
    {
        data = value;
        left = NULL;
        right = NULL;
    }
};

// Insert function
Node* insert(Node* root, int value)
{
    // Create node if empty
    if (root == NULL)
    {
        return new Node(value);
    }

    // Go left
    if (value < root->data)
    {
        root->left = insert(root->left, value);
    }

    // Go right
    else
    {
        root->right = insert(root->right, value);
    }

    return root;
}

// Print BST in sorted order
void inorder(Node* root)
{
    if (root == NULL)
    {
        return;
    }

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

// Recursive search function
bool search(Node* root, int key)
{
    // Value not found
    if (root == NULL)
    {
        return false;
    }

    // Value found
    if (root->data == key)
    {
        return true;
    }

    // Search left side
    if (key < root->data)
    {
        return search(root->left, key);
    }

    // Search right side
    return search(root->right, key);
}

int main()
{
    Node* root = NULL;

    int n, value, key;

    cout << "Enter number of values: ";
    cin >> n;

    cout << "Enter values: ";

    // Insert values
    for (int i = 0; i < n; i++)
    {
        cin >> value;
        root = insert(root, value);
    }

    // Display BST
    cout << "\nBST in ascending order: ";
    inorder(root);

    // Search value
    cout << "\nEnter value to search: ";
    cin >> key;

    // Check result
    if (search(root, key))
    {
        cout << "Value found.";
    }
    else
    {
        cout << "Value not found.";
    }

    return 0;
}